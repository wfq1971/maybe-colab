This is now being archived, and left available for others to review/modify as they see fit. I had not updated it for some time, and I think the core functionality having to deal with presets has had some work and will eventually reach an stable state (if it has not already).  

I might revisit this some day, to provide a presets enhanced version. But this is not likely, as there are other approaches to address dynamic configurations.
